package verifica_15_05;

import java.util.ArrayList;
import java.util.HashMap;

public class Gestionale {
    HashMap<String, Cliente> clienti = new HashMap<>();
    ArrayList<Conto> conti = new ArrayList<>();
    HashMap<Integer, Operazione> op = new HashMap<>();

    public void add(Cliente x) {
        clienti.put(x.getCF(), x);
    }

    public void remove(Cliente x) {
        clienti.remove(x.getCF());
    }

    public void add(Conto x) {
        conti.add(x);
    }

    public void remove(Conto x) {
        conti.remove(x);
    }

    public void add(Operazione x) {
        op.put(x.getId(), x);
    }

    public void remove(Operazione x) {
        op.remove(x.getId());
    }

    public void addConto(Cliente x) {
        add(new Conto(x.getId()));
    }

    public void doOp(Operazione x) {
        if(op.get(x.getId()) == null) throw new IllegalArgumentException("Conto non esistente");

        if(x.getImp() > x.getCc().getSaldof() && x.getImp() > 1500 && x.getImp() > x.getCc().getMove())
            throw new IllegalArgumentException("Superato il limite");

        x.getCc().setSaldo(x.getImp());
    }

    public void listCli() {
        String[] toRet = clienti.toString().split(", ");
        for(int i = 0 ; i < toRet.length ; i++) {
            System.out.println(toRet[i]);
            System.out.println();
        }
    }

    public void listConti() {
        String[] toRet = conti.toString().split(", ");
        for(int i = 0 ; i < toRet.length ; i++) {
            System.out.println(toRet[i]);
            System.out.println();
        }
    }

    public void listOp() {
        String[] toRet = op.toString().split(", ");
        for(int i = 0 ; i < toRet.length ; i++) {
            System.out.println(toRet[i]);
            System.out.println();
        }
    }
}
